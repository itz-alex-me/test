import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useEffect } from 'react';
import { supabase } from './lib/supabase';
import { useAuthStore } from './store/auth';
import Layout from './components/Layout';
import Home from './pages/Home';
import Events from './pages/Events';
import Members from './pages/Members';
import Projects from './pages/Projects';
import Contact from './pages/Contact';
import AdminDashboard from './pages/admin/Dashboard';
import AdminEvents from './pages/admin/Events';
import AdminMembers from './pages/admin/Members';
import AdminProjects from './pages/admin/Projects';
import Login from './pages/Login';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  const setUser = useAuthStore((state) => state.setUser);

  useEffect(() => {
    // Set initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, [setUser]);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="events" element={<Events />} />
          <Route path="members" element={<Members />} />
          <Route path="projects" element={<Projects />} />
          <Route path="contact" element={<Contact />} />
          <Route path="login" element={<Login />} />
          
          {/* Admin Routes */}
          <Route path="admin" element={<ProtectedRoute />}>
            <Route index element={<AdminDashboard />} />
            <Route path="events" element={<AdminEvents />} />
            <Route path="members" element={<AdminMembers />} />
            <Route path="projects" element={<AdminProjects />} />
          </Route>
        </Route>
      </Routes>
    </Router>
  );
}

export default App;